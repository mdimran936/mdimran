# Snapdeal-Clone
Built the clone of Snapdeal website. Features :- Product details, Explore section to view products, Cart page, Payment Gateway

## This website is hosted on herokuapp.com
Link to visit site:- https://snapdeal-clone.vercel.app/

## Glimpse of the project

### Login Page
<img src="https://miro.medium.com/max/1400/1*L9gu-3TZ3mORn16w6TUOgg.jpeg" />

### Home Page:
<img src="https://miro.medium.com/max/1400/1*hN0K9HfuFT7QluJ0noZSHA.jpeg" width="100%" height="auto" />

### Product Page:
<img src="https://miro.medium.com/max/1400/1*9PcaCgFr2Dc5Sq3fSbYHNQ.jpeg" width="100%" height="auto" />

### Cart page

<img src="https://miro.medium.com/max/1400/1*7KyZyFdzRFjlp_6VAhfuzQ.jpeg" width="100%" height="auto" />




## Technology used

<img src="https://www.freepnglogos.com/uploads/html5-logo-png/html5-logo-devextreme-multi-purpose-controls-html-javascript-3.png" height="100px" />

## Functionality
* Login/Signup
* Product page
* Add product to cart
* Dynamic cart page



